# hey-kodi
Kodi automation through iOS shortcuts and Siri.
